from django.contrib import admin
from .models import Recipe
from .models import User
from .models import BMI
# Register your models here.

admin.site.register(Recipe)

admin.site.register(User)

admin.site.register(BMI)