from django.apps import AppConfig


class FijifitConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'FijiFit'
