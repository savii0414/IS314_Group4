from django.db import models


# Create your models here.
class Recipe(models.Model):
    Recipe_id = models.AutoField
    Recipe_title = models.CharField(max_length = 100)
    Recipe_desc = models.CharField(max_length = 5000)
    Recipe_img= models.ImageField(default='No Image selected',upload_to='media/')
    Recipe_ing = models.CharField(max_length = 5000)
    def __str__ (self):
        return self.Recipe_title
    
class User(models.Model):
    user_id = models.AutoField
    user_fname = models.CharField(max_length = 100)
    user_lname = models.CharField(max_length = 100)
    user_email = models.CharField(max_length = 5000)
    user_pwd= models.CharField(max_length = 5000)
    def __str__ (self):
        return self.user_fname

class BMI(models.Model):
    id= models.AutoField
    Height = models.FloatField(max_length= 5, null=False, blank=False)
    Weight = models.FloatField(max_length= 5, null=False, blank=False)
    bmi = models.FloatField()
    def __str__(self):
        return str(self.bmi)