from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .import views

urlpatterns = [

    path("SignUp/", views.SignUp, name="SignUp"),
    path("Login/", views.Login, name="Login"),
    path("MealRec/", views.MealRec, name="MealRecommendations"),  
    path("BMI/", views.Cal_BMI, name="cal_bmi_view"),  
    path("", views.DashBoard, name="DashBoard"), 
    path("siderBar/", views.SideBar, name="Siderbar"),   
]