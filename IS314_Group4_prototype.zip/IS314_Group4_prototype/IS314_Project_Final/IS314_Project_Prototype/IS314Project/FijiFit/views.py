from django.http import HttpResponse
from .models import Recipe
from .models import User
from .models import BMI
from django.shortcuts import render

# Create your views here.


def MealRec (request):
    obj = Recipe.objects.all()
    context = {
        "obj":obj,
    }
    return render(request, 'MealRec.html', context)

def SignUp (request):
    if request.method =='POST':
        user_fname = request.POST.get('user_fname')
        user_lname = request.POST.get('user_lname')
        user_email = request.POST.get('user_email')
        user_pwd = request.POST.get('user_pwd')

        my_user = User.objects.create_user(user_fname, user_lname, user_email, user_pwd)
        my_user.save()
        return HttpResponse("Account created Successfully")
        
    return render(request, 'SignUp.html')

def Login (request):
    return render(request, 'Login.html')

def SideBar (request):
    return render(request, 'SideBar.html')

def DashBoard (request):
    obj = BMI.objects.all()
    context = {
        "obj":obj,
    }
    return render(request, 'DashBoard.html', context)
    
def Base (request):
    return render(request, 'base.html')

def bmi_calc(Weight, Height, bmi):
    
    newBMI = Weight / ((Height/100) ** 2)
    return round(newBMI, 2) if bmi is None else bmi


def Cal_BMI(request):
  
    if request.method == 'POST':
        Height = float(request.POST.get('Height')[:3])
        Weight = float(request.POST.get('Weight')[:3])
        bmi = Weight / ((Height / 100) ** 2)   
        
        # Server-side validation
        try:
            if Height <= 0.0  or Weight <= 0.0:
                return HttpResponse("Invalid Input")
            elif Height == 0 or Weight == 0:
                return HttpResponse("Invalid Input")
            
        except ValueError:
            if (Height.strip() == "" or Weight.strip() == "" ):
                return HttpResponse("Input can't be empty!")
            
        # Retrieve the existing BMI record if available
        existing_record = BMI.objects.first()

        # Calculate new BMI based on existing record or None
        bmi = bmi_calc(Weight, Height, round(bmi, 2) if existing_record else None)

        # Create or update the existing record
        if existing_record:
            existing_record.Weight = Weight
            existing_record.Height = Height
            existing_record.bmi = bmi
            existing_record.save()
        else:
            BMI.objects.create(Weight=Weight, Height=Height, bmi=bmi)
            
    return render(request, 'BMI.html')






